const express = require('express');
const router = express.Router();

const {
  uploadMiddleware,
  uploadImages
} = require('../controllers/uploadpic'); // ⬅️ เรียกจาก controller

router.post('/upload', uploadMiddleware, uploadImages); // ✅ ครบ middleware + handler

module.exports = router;
